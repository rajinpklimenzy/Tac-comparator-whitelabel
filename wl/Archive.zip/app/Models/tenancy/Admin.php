<?php

namespace App\Models\tenancy;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    //
}
